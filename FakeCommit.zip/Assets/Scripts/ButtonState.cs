using System;
using UnityEngine;

public enum ButtonState
{
    Pressed,
    Relaesed
}
